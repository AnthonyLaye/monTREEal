/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.27.0.3789.8ef58d1 modeling language!*/

package ca.mcgill.ecse321.TreePLESystem.model;

// line 18 "../../../../../../../../ump/180117838895/model.ump"
// line 54 "../../../../../../../../ump/180117838895/model.ump"
public abstract class Person
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Person Associations
  private Municipality municipality;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Person(Municipality aMunicipality)
  {
    boolean didAddMunicipality = setMunicipality(aMunicipality);
    if (!didAddMunicipality)
    {
      throw new RuntimeException("Unable to create person due to municipality");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public Municipality getMunicipality()
  {
    return municipality;
  }
  /* Code from template association_SetOneToMany */
  public boolean setMunicipality(Municipality aMunicipality)
  {
    boolean wasSet = false;
    if (aMunicipality == null)
    {
      return wasSet;
    }

    Municipality existingMunicipality = municipality;
    municipality = aMunicipality;
    if (existingMunicipality != null && !existingMunicipality.equals(aMunicipality))
    {
      existingMunicipality.removePerson(this);
    }
    municipality.addPerson(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Municipality placeholderMunicipality = municipality;
    this.municipality = null;
    if(placeholderMunicipality != null)
    {
      placeholderMunicipality.removePerson(this);
    }
  }

}