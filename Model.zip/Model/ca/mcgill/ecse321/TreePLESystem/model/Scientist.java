/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.27.0.3789.8ef58d1 modeling language!*/

package ca.mcgill.ecse321.TreePLESystem.model;
import java.util.*;

// line 27 "../../../../../../../../ump/180117838895/model.ump"
// line 64 "../../../../../../../../ump/180117838895/model.ump"
public class Scientist extends Person
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Scientist Attributes
  private String name;

  //Scientist Associations
  private List<Survey> surveys;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Scientist(Municipality aMunicipality, String aName)
  {
    super(aMunicipality);
    name = aName;
    surveys = new ArrayList<Survey>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setName(String aName)
  {
    boolean wasSet = false;
    name = aName;
    wasSet = true;
    return wasSet;
  }

  public String getName()
  {
    return name;
  }
  /* Code from template association_GetMany */
  public Survey getSurvey(int index)
  {
    Survey aSurvey = surveys.get(index);
    return aSurvey;
  }

  public List<Survey> getSurveys()
  {
    List<Survey> newSurveys = Collections.unmodifiableList(surveys);
    return newSurveys;
  }

  public int numberOfSurveys()
  {
    int number = surveys.size();
    return number;
  }

  public boolean hasSurveys()
  {
    boolean has = surveys.size() > 0;
    return has;
  }

  public int indexOfSurvey(Survey aSurvey)
  {
    int index = surveys.indexOf(aSurvey);
    return index;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfSurveys()
  {
    return 0;
  }
  /* Code from template association_AddManyToManyMethod */
  public boolean addSurvey(Survey aSurvey)
  {
    boolean wasAdded = false;
    if (surveys.contains(aSurvey)) { return false; }
    surveys.add(aSurvey);
    if (aSurvey.indexOfScientist(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aSurvey.addScientist(this);
      if (!wasAdded)
      {
        surveys.remove(aSurvey);
      }
    }
    return wasAdded;
  }
  /* Code from template association_RemoveMany */
  public boolean removeSurvey(Survey aSurvey)
  {
    boolean wasRemoved = false;
    if (!surveys.contains(aSurvey))
    {
      return wasRemoved;
    }

    int oldIndex = surveys.indexOf(aSurvey);
    surveys.remove(oldIndex);
    if (aSurvey.indexOfScientist(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aSurvey.removeScientist(this);
      if (!wasRemoved)
      {
        surveys.add(oldIndex,aSurvey);
      }
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addSurveyAt(Survey aSurvey, int index)
  {  
    boolean wasAdded = false;
    if(addSurvey(aSurvey))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSurveys()) { index = numberOfSurveys() - 1; }
      surveys.remove(aSurvey);
      surveys.add(index, aSurvey);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveSurveyAt(Survey aSurvey, int index)
  {
    boolean wasAdded = false;
    if(surveys.contains(aSurvey))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSurveys()) { index = numberOfSurveys() - 1; }
      surveys.remove(aSurvey);
      surveys.add(index, aSurvey);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addSurveyAt(aSurvey, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    ArrayList<Survey> copyOfSurveys = new ArrayList<Survey>(surveys);
    surveys.clear();
    for(Survey aSurvey : copyOfSurveys)
    {
      aSurvey.removeScientist(this);
    }
    super.delete();
  }


  public String toString()
  {
    return super.toString() + "["+
            "name" + ":" + getName()+ "]";
  }
}