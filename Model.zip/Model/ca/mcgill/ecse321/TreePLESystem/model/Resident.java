/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.27.0.3789.8ef58d1 modeling language!*/

package ca.mcgill.ecse321.TreePLESystem.model;
import java.util.*;
import java.sql.Date;

// line 33 "../../../../../../../../ump/180117838895/model.ump"
// line 75 "../../../../../../../../ump/180117838895/model.ump"
public class Resident extends Person
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Resident Associations
  private List<Tree> owns;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Resident(Municipality aMunicipality)
  {
    super(aMunicipality);
    owns = new ArrayList<Tree>();
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetMany */
  public Tree getOwn(int index)
  {
    Tree aOwn = owns.get(index);
    return aOwn;
  }

  public List<Tree> getOwns()
  {
    List<Tree> newOwns = Collections.unmodifiableList(owns);
    return newOwns;
  }

  public int numberOfOwns()
  {
    int number = owns.size();
    return number;
  }

  public boolean hasOwns()
  {
    boolean has = owns.size() > 0;
    return has;
  }

  public int indexOfOwn(Tree aOwn)
  {
    int index = owns.indexOf(aOwn);
    return index;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfOwns()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public Tree addOwn(String aSpecies, float aHeight, int aAge, Date aDate, float aDiameter, float aLongitude, float aLatitude, Municipality aMunicipality)
  {
    return new Tree(aSpecies, aHeight, aAge, aDate, aDiameter, aLongitude, aLatitude, aMunicipality, this);
  }

  public boolean addOwn(Tree aOwn)
  {
    boolean wasAdded = false;
    if (owns.contains(aOwn)) { return false; }
    Resident existingResident = aOwn.getResident();
    boolean isNewResident = existingResident != null && !this.equals(existingResident);
    if (isNewResident)
    {
      aOwn.setResident(this);
    }
    else
    {
      owns.add(aOwn);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeOwn(Tree aOwn)
  {
    boolean wasRemoved = false;
    //Unable to remove aOwn, as it must always have a resident
    if (!this.equals(aOwn.getResident()))
    {
      owns.remove(aOwn);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addOwnAt(Tree aOwn, int index)
  {  
    boolean wasAdded = false;
    if(addOwn(aOwn))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfOwns()) { index = numberOfOwns() - 1; }
      owns.remove(aOwn);
      owns.add(index, aOwn);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveOwnAt(Tree aOwn, int index)
  {
    boolean wasAdded = false;
    if(owns.contains(aOwn))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfOwns()) { index = numberOfOwns() - 1; }
      owns.remove(aOwn);
      owns.add(index, aOwn);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addOwnAt(aOwn, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    for(int i=owns.size(); i > 0; i--)
    {
      Tree aOwn = owns.get(i - 1);
      aOwn.delete();
    }
    super.delete();
  }

}